function mainPageClick()
 {
    window.location="MainLOCUS.html"; 
 }
   
   
function backClick()
 {
    window.location="AvailableEnglishClasses.html"; 
 }
 
